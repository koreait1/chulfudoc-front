export default function Unauthorized() {
  return <h1>접근 권한이 없습니다.</h1>
}
