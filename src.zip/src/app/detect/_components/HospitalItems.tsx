import React from 'react'

const HospitalItems = ({ items }) => {
  return <></>
}

export default React.memo(HospitalItems)