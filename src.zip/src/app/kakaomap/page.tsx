import MapContainer from './_containers/MapContainer'

export default function MapPage() {
  return <MapContainer />
}
