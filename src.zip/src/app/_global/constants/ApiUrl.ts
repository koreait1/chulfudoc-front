export enum ApiUrl {
    SENDCODE = '/email/verify?email=',
    CHECKCODE = '/email/check?authNum='
}