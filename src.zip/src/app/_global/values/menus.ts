const menus = {
  '/admin/member': [{ link: '/admin/member', text: '회원목록' }],
  '/admin/board': [
    { link: '/admin/board', text: '게시판 목록' },
    { link: '/admin/board/register', text: '게시판 등록' },
    { link: '/admin/board/posts', text: '게시글 관리' },
  ],
}

export default menus
