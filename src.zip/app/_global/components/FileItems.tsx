import React from 'react'

const FileItems = ({ items }) => {
  return <></>
}

export default React.memo(FileItems)
