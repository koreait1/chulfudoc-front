type MessageType = {
    children?: string[] | string
    color?: string
    message?: string[] | string
}

export default MessageType