type TitleType = {
  children: React.ReactNode
  border?: boolean | string
  center?: boolean | string
}

export default TitleType