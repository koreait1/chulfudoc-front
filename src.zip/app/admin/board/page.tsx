import ListContainer from './_containers/ListContainer'

export default function BoardListPage() {
  return <ListContainer />
}
