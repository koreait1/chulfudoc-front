'use client'

import React from 'react'

const ListContainer = () => {
  return <></>
}

export default React.memo(ListContainer)
