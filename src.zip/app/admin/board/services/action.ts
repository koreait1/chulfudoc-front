'use server'
export async function processBoardConfig(errors, formData: FormData) {
    
}